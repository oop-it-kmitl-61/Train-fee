/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author JustALemon
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

  public static void main(String[] args) throws IOException {
    File excelFile = new File("TrainFee.xls");
    FileInputStream fis = new FileInputStream(excelFile);

    // we create an XSSF Workbook object for our XLSX Excel File
    Workbook workbook = new HSSFWorkbook(fis);
    // we get first sheet
    int first = 0;
    int second = 2;
    int third = 2;
    HSSFSheet sheet = (HSSFSheet) workbook.getSheetAt(first);
    HSSFRow row = sheet.getRow(second);
    HSSFCell cell = row.getCell(third);
    String keep = cell.toString();
    System.out.println(keep);
    workbook.close();
    fis.close();
  }
	
}
