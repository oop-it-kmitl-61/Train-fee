/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oopproject;

import java.io.IOException;

/**
 *
 * @author JustALemon
 */
public class OOPProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        new MainGUI1().start();
        System.out.println(new ReadExcel().read(4, 0, 1));
        System.out.println(new TimeCalculator().calculateTime(3, 1, 8));
    }
    
}
